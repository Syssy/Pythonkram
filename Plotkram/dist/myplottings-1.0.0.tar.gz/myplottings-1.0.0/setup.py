from distutils.core import setup

setup(
    name = "myplottings",
    version = "1.0.0",
    py_modules = ['plotkram'],
    author = 'elly',
    description = 'zum histogramme und qq plotten',
    ) 
