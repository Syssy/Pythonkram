# -*- coding: utf-8 -*-
import scipy.stats
import csv
import matplotlib.pyplot as plt
import statsmodels.api as sm
import numpy as np

def plot_histogram(datei, histogram_separate, histogram_spec, num_bins=1000):
    with open(datei, 'rb') as csvfile:
        myreader = csv.reader(csvfile, delimiter = ";",quoting=csv.QUOTE_NONE)
        liste = []
        # Erstelle Liste, mit der plt.hist umgehen kann
        for row in myreader:
            unterliste = []
            for r in row:
                r2 = float(r)
                unterliste.append(r2)
            liste.append(unterliste)
        # Erstelle Histogramme, TODO: Flexibel an Anzahl anpassen     
        if histogram_separate:
	    print "erstelle separate histogramme"
            #meine_range= (length, length+ length*(1/min(params)))
            #meine_range = (length, 4*length)
            meine_range = None
            #print meine_range
            figg = plt.figure()
            ax = figg.add_subplot(221)
            n, bins, patches = plt.hist(liste[0], num_bins, range = meine_range, normed=1, alpha=0.5 )
            ax = figg.add_subplot(222)
            n, bins, patches = plt.hist(liste[1], num_bins, range = meine_range, normed=1, alpha=0.5 )
            ax = figg.add_subplot(223)
            n, bins, patches = plt.hist(liste[2], num_bins, range = meine_range, normed=1, alpha=0.5 )
            ax = figg.add_subplot(224)
            n, bins, patches = plt.hist(liste[3], num_bins, range = meine_range, normed=1, alpha=0.5 )
        

        # ein gemeinsames Histogramm aller Datensätze erstellen; entspricht Spektrum
        if histogram_spec:
            #meine_range= (length, length+ length*(1/min(single_params)))
            meine_range = None
            print "Erstelle Spektrum"
            figg = plt.figure()
            for row in liste:
                n, bins, patches = plt.hist(liste, num_bins, normed=1, alpha=0.5 )
                print "Hist erstellt",#, n, bins, patches#,(time.clock()-startzeit)
        plt.show()
    

def plot_qq(datei, qq_Plot, fit_qq_Plot, vergleich = scipy.stats.invgauss):
    with open(datei, 'rb') as csvfile:
        myreader = csv.reader(csvfile, delimiter = ";",quoting=csv.QUOTE_NONE)
        liste = []
        # Erstelle Liste wie oben
        for row in myreader:
            unterliste = []
            for r in row:
                r2 = float(r)
                unterliste.append(r2)
            liste.append(unterliste)

    # Und einen qq-Plot erstellen, evtl Parameter zur vergleichsfunktion müssen
    # per Hand eingestellt werden
    if qq_Plot:
        print "erstelle qq-Plot",
        fig = plt.figure()
        ax = fig.add_subplot(221)
        sm.qqplot (np.array(liste[0]), vergleich, distargs= (0.005,),  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[0]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr2",
        ax = fig.add_subplot(222)
        sm.qqplot (np.array(liste[1]), vergleich, distargs= (0.005,),  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[1]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr3",
        ax = fig.add_subplot(223)
        sm.qqplot (np.array(liste[2]), vergleich, distargs= (0.005,),  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[2]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr4",
        ax = fig.add_subplot(224)
        sm.qqplot (np.array(liste[3]), vergleich, distargs= (0.005,),  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[3]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "qqplot erstellt"

    # qq-Plot mit automatischem fit zur Vergleichsfunktion
    if fit_qq_Plot:
        print "erstelle fit-qq-plot", 
        fig = plt.figure()
        ax = fig.add_subplot(221)
        sm.qqplot (np.array(liste[0]), vergleich, fit = True,  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[0]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr2",
        ax = fig.add_subplot(222)
        sm.qqplot (np.array(liste[1]), vergleich, fit = True,  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[1]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr3",
        ax = fig.add_subplot(223)
        sm.qqplot (np.array(liste[2]), vergleich, fit = True,  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[2]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "nr4",
        ax = fig.add_subplot(224)
        sm.qqplot (np.array(liste[3]), vergleich, fit = True,  line = 'r', ax =ax)
        #txt = ax.text(-1.8, 3500, str(params[3]) ,verticalalignment='top')
        #txt.set_bbox(dict(facecolor='k', alpha=0.1))
        print "qqplot erstellt"

    plt.show()
