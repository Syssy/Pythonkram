from distutils.core import setup

setup(
    name = "simulationsklasse",
    version = "1.0.0",
    py_modules = ['simulation'],
    author = 'elly',
    description = 'speichert neben den Zeiten auch Parameter (ps, pm), Laenge der MCC und Anzahl der Teilchen',
    ) 
